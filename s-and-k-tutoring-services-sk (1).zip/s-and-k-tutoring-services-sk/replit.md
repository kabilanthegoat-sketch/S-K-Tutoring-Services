# Running on Replit

This S&K Tutoring site uses React, TypeScript, TanStack Start, Tailwind, Vite,
Google Sheets for enquiries, and Supabase for reviews.

## Development

- Use the **Start application** workflow (or the Run button).
- The workflow runs `bun run dev`.
- Vite listens on `0.0.0.0:5000` and accepts Replit preview hosts.
- Node.js 22 and Bun are configured in `.replit`; dependencies use `bun.lock`.
- To reinstall the existing dependencies, run `bun install --frozen-lockfile`.
- Existing scripts include `bun run build`, `bun run test`, and `bun run lint`.
  Run Vitest with Node.js available on PATH.

## Backend configuration

The imported `.env` supplies the existing Supabase URL and publishable key.
Browser code uses `VITE_SUPABASE_URL` and `VITE_SUPABASE_PUBLISHABLE_KEY`;
server code uses `SUPABASE_URL` and `SUPABASE_PUBLISHABLE_KEY`.
Google Sheets enquiries are appended server-side through the connected Replit
Google Sheets integration. Keep the connector call on the server; never expose
Google credentials in browser code.

## Setup verification and known import issues

- The home, subjects, tutors, pricing, reviews, and FAQ routes returned HTTP 200.
- The home page was visually checked in preview with no browser errors.
- Supabase remains the review store. Enquiry submissions use the connected
  Google Sheets integration through a server-only request.
- Luke's photo has been restored from the uploaded image. It is imported into
  the Vite build so the production output includes it in `assets/`.
- Enquiries are saved to the private Google Sheet created for the site. Supabase
  remains the review store; do not apply the former public-inquiry migration.
- The imported routing tests in `src/test/app-routing.test.tsx` fail under
  Node.js because the rendered container remains empty. These need a
  separate test-harness fix; the live routes load successfully.