# Roadmap

- [x] Add Luke's uploaded tutor photo
- [x] Add the second WhatsApp number and email contact
- [x] Verify the updated site
- [x] Prepare a clean source-code download
