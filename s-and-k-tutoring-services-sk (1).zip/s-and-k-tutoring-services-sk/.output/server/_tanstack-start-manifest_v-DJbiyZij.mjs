//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DJbiyZij.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/runner/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/faq",
			"/pricing",
			"/reviews",
			"/subjects",
			"/tutors"
		],
		preloads: ["/assets/index-DFsERu8G.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DFsERu8G.js"
		} }]
	},
	"/": {
		filePath: "/home/runner/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-CgMfaRXM.js",
			"/assets/check-B5qVUWg6.js",
			"/assets/Interactive-CNgMmvje.js"
		]
	},
	"/faq": {
		filePath: "/home/runner/workspace/src/routes/faq.tsx",
		children: void 0,
		preloads: ["/assets/faq-BVKts8Os.js"]
	},
	"/pricing": {
		filePath: "/home/runner/workspace/src/routes/pricing.tsx",
		children: void 0,
		preloads: [
			"/assets/pricing-CyQomN24.js",
			"/assets/check-B5qVUWg6.js",
			"/assets/Interactive-CNgMmvje.js"
		]
	},
	"/reviews": {
		filePath: "/home/runner/workspace/src/routes/reviews.tsx",
		children: void 0,
		preloads: ["/assets/reviews-DCSQbFED.js", "/assets/Interactive-CNgMmvje.js"]
	},
	"/subjects": {
		filePath: "/home/runner/workspace/src/routes/subjects.tsx",
		children: void 0,
		preloads: ["/assets/subjects-CWnU00iq.js", "/assets/Interactive-CNgMmvje.js"]
	},
	"/tutors": {
		filePath: "/home/runner/workspace/src/routes/tutors.tsx",
		children: void 0,
		preloads: ["/assets/tutors-Dx57YhPO.js", "/assets/Interactive-CNgMmvje.js"]
	}
} });
//#endregion
export { tsrStartManifest };
