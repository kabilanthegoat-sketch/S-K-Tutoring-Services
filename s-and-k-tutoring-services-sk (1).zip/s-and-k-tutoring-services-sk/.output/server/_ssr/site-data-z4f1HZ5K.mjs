//#region node_modules/.nitro/vite/services/ssr/assets/site-data-z4f1HZ5K.js
var image_1790948844448_default = "/assets/image_1790948844448-CLwXxnLL.png";
var LOGO = "https://i.postimg.cc/dtW3NT4b/SK-LOGO-jpeg.jpg";
var WHATSAPP_2 = "27638452735";
var EMAIL = "sktutoring28@gmail.com";
var INSTAGRAM = "sk_tutoring123";
var subjects = [
	{
		key: "math",
		title: "Mathematics",
		tag: "Core Concepts & Algebra",
		grade: "Grades 4 - 9",
		description: "Building strong numeric reasoning, step-by-step problem-solving methods, and algebraic confidence.",
		focus: [
			"Numbers & Operations",
			"Patterns & Algebra",
			"Geometry",
			"Measurement & Data Handling"
		]
	},
	{
		key: "english",
		title: "English",
		tag: "Grammar & Comprehension",
		grade: "Grades 4 - 9",
		description: "Developing fluency in reading comprehension, formal writing structures, and language mechanics.",
		focus: [
			"Reading Comprehension",
			"Grammar & Editing",
			"Creative Writing",
			"Vocabulary"
		]
	},
	{
		key: "afrikaans",
		title: "Afrikaans (FAL)",
		tag: "Language & Vocabulary",
		grade: "Grades 4 - 9",
		description: "Mastering foundational rules, sentence structures, and oral/written comprehension.",
		focus: [
			"STOMPI Rules",
			"Taal Rules",
			"Comprehension Passages",
			"Paragraph Writing"
		]
	},
	{
		key: "ems",
		title: "EMS",
		tag: "Accounting & Economy Basics",
		grade: "Grades 7 - 9",
		description: "Introducing double-entry accounting principles and basic macroeconomic concepts.",
		focus: [
			"Accounting Equations",
			"Cash Receipts/Payments Journals",
			"General Ledger",
			"Entrepreneurship"
		]
	},
	{
		key: "geography",
		title: "Geography",
		tag: "Mapwork",
		grade: "Grades 4 - 9",
		description: "Mastering practical map skills, grid references, scale, and natural geography concepts.",
		focus: [
			"Mapwork Skills",
			"Latitudes & Time Zones",
			"Climate & Weathering",
			"Settlement Studies"
		]
	},
	{
		key: "biology",
		title: "Biology",
		tag: "Life Systems & Ecosystems",
		grade: "Grades 4 - 9",
		description: "Exploring living systems, human biology, ecology, and biological processes.",
		focus: [
			"Photosynthesis & Respiration",
			"Human Systems",
			"Ecosystems",
			"Cells & Life Processes"
		]
	},
	{
		key: "physics",
		title: "Physics",
		tag: "Matter, Energy & Forces",
		grade: "Grades 4 - 9",
		description: "Understanding how matter, energy and forces shape the world around us.",
		focus: [
			"Matter & Materials",
			"Energy & Change",
			"Forces & Motion",
			"Electric Circuits"
		]
	},
	{
		key: "history",
		title: "History",
		tag: "Source Analysis",
		grade: "Grades 4 - 9",
		description: "Learning to analyse sources, build arguments and write structured historical essays.",
		focus: [
			"Source Analysis",
			"Essay Writing",
			"South African History",
			"World History"
		]
	},
	{
		key: "technology",
		title: "Technology",
		tag: "Practical & Theory Study",
		grade: "Grades 7 - 9",
		description: "Combining design thinking with technical theory and practical projects.",
		focus: [
			"Design Process",
			"Structures",
			"Mechanical Systems",
			"Electrical Systems"
		]
	},
	{
		key: "homework",
		title: "Homework Support",
		tag: "Daily Task Guidance",
		grade: "Grades 4 - 9",
		description: "Guided support to complete daily tasks and projects with understanding.",
		focus: [
			"Daily Homework",
			"Projects & Assignments",
			"Study Habits",
			"Time Management"
		]
	},
	{
		key: "exam",
		title: "Exam Preparation",
		tag: "Revision Techniques",
		grade: "Grades 4 - 9",
		description: "Structured revision and practice to walk into exams prepared and confident.",
		focus: [
			"Past Papers",
			"Revision Plans",
			"Exam Technique",
			"Weak Area Drills"
		]
	}
];
var tutors = [
	{
		name: "Kabilan Kathiravan",
		role: "Science & Mathematics Tutor",
		subjects: [
			"Mathematics",
			"Physics",
			"Technology",
			"History",
			"Geography",
			"Afrikaans"
		],
		photo: "https://i.postimg.cc/nhKQMQmk/Whats-App-Image-2026-07-03-at-2-30-30-PM-(3).jpg"
	},
	{
		name: "Shriyans Sharma",
		role: "Business & Mathematics Tutor",
		subjects: [
			"English",
			"Afrikaans",
			"EMS",
			"History",
			"Geography",
			"Mathematics"
		],
		photo: "https://i.postimg.cc/c4LBGHkV/Whats-App-Image-2026-07-03-at-2-02-40-PM-(1).jpg"
	},
	{
		name: "Achuma Nomana",
		role: "Mathematics & Science Tutor",
		subjects: [
			"Physics",
			"Biology",
			"Geography",
			"History",
			"Mathematics",
			"English"
		],
		photo: "https://i.postimg.cc/L5HwppG3/Whats-App-Image-2026-07-03-at-11-54-09-AM.jpg"
	},
	{
		name: "Luke",
		role: "Afrikaans & Mathematics Tutor",
		subjects: [
			"Mathematics",
			"English",
			"Afrikaans",
			"Physics",
			"Biology",
			"History",
			"Geography"
		],
		photo: image_1790948844448_default
	}
];
var staticReviews = [
	{
		name: "Jaiden",
		rating: 5,
		comment: "My marks improved by 30% thanks to S&K!"
	},
	{
		name: "Leyla",
		rating: 5,
		comment: "Achuma is an incredible tutor, highly recommend."
	},
	{
		name: "Sarah M. (Parent)",
		rating: 5,
		comment: "S&K Tutoring helped my Grade 7 son improve his Math marks from 55% to 78% in just one term! Highly recommended."
	},
	{
		name: "Jason K. (Grade 9 Student)",
		rating: 5,
		comment: "The tutors are patient and explain complex Science topics in a way that actually makes sense."
	}
];
var faqs = [
	{
		q: "How much does tutoring cost?",
		a: "A flat rate of R60 per hour across all subjects and grades."
	},
	{
		q: "How do payments work?",
		a: "Invoices are sent at the end of every month. Your monthly total is calculated dynamically based strictly on the number of lessons your child attended."
	},
	{
		q: "How do online lessons work?",
		a: "Online lessons are conducted via interactive video calls where we share screens, work through digital whiteboards, and provide real-time feedback on exercises."
	},
	{
		q: "Where do in-person sessions take place?",
		a: "Please contact us directly via WhatsApp to coordinate specific arrangements, locations, and travel spaces."
	},
	{
		q: "What learning materials are included?",
		a: "We provide curated worksheets, practice questions, and specific exam-preparation reviews targeting identified areas of weakness."
	},
	{
		q: "Which grades do you tutor?",
		a: "We specialise in personalised academic support for learners in Grades 4 through 9."
	}
];
//#endregion
export { faqs as a, tutors as c, WHATSAPP_2 as i, INSTAGRAM as n, staticReviews as o, LOGO as r, subjects as s, EMAIL as t };
