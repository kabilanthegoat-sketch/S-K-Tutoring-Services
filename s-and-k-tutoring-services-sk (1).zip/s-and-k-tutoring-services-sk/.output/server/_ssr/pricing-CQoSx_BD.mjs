import { o as __toESM } from "../_runtime.mjs";
import { c as tutors, s as subjects } from "./site-data-z4f1HZ5K.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { u as Check } from "../_libs/lucide-react.mjs";
import { a as TSS_SERVER_FUNCTION, l as createServerFn } from "./createServerFn-DDDJMFWM.mjs";
import { t as getServerFnById } from "../__23tanstack-start-server-fn-resolver-DZSdqhz-.mjs";
import { t as Calculator } from "./Interactive-Cg8sMcil.mjs";
import { n as stringType, t as objectType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pricing-CQoSx_BD.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function validateEnquiry(input) {
	if (input == null || typeof input !== "object" || Array.isArray(input)) throw new TypeError("Invalid enquiry data.");
	const record = input;
	const expectedFields = [
		"parent_name",
		"contact_number",
		"child_grade",
		"subject",
		"preferred_tutor"
	];
	if (Object.keys(record).length !== expectedFields.length || expectedFields.some((field) => !(field in record))) throw new TypeError("Invalid enquiry data.");
	const { parent_name, contact_number, child_grade, subject, preferred_tutor } = record;
	if (typeof parent_name !== "string" || parent_name.trim().length < 1 || parent_name.trim().length > 100 || typeof contact_number !== "string" || !/^[+\d\s()-]{6,20}$/.test(contact_number.trim()) || typeof child_grade !== "string" || child_grade.length < 1 || child_grade.length > 20 || typeof subject !== "string" || subject.length < 1 || subject.length > 50 || typeof preferred_tutor !== "string" || preferred_tutor.length > 50) throw new TypeError("Invalid enquiry data.");
	return {
		parent_name: parent_name.trim(),
		contact_number: contact_number.trim(),
		child_grade,
		subject,
		preferred_tutor
	};
}
var saveEnquiry = createServerFn({ method: "POST" }).validator(validateEnquiry).handler(createSsrRpc("60594993e44b3fe8130e277ac17d598acacc666d37044a1df0dd61b17c512dbf"));
var schema = objectType({
	parent_name: stringType().trim().min(1, "Please enter your name").max(100),
	contact_number: stringType().trim().regex(/^[+\d\s()-]{6,20}$/, "Enter a valid contact number"),
	child_grade: stringType().min(1, "Choose a grade"),
	subject: stringType().min(1, "Choose a subject"),
	preferred_tutor: stringType().max(50)
});
var steps = [
	"Parent",
	"Learner",
	"Tutor"
];
var field = "w-full rounded-lg border border-input bg-secondary px-4 py-3 outline-none focus:border-primary";
function InquiryForm() {
	const [step, setStep] = (0, import_react.useState)(0);
	const [d, setD] = (0, import_react.useState)({
		parent_name: "",
		contact_number: "",
		child_grade: "",
		subject: "",
		preferred_tutor: "No preference"
	});
	const [err, setErr] = (0, import_react.useState)("");
	const [done, setDone] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const set = (k, v) => setD({
		...d,
		[k]: v
	});
	const check = (keys) => {
		const r = schema.pick(Object.fromEntries(keys.map((k) => [k, true]))).safeParse(d);
		if (!r.success) {
			setErr(r.error.issues[0]?.message ?? "Please check your details");
			return false;
		}
		setErr("");
		return true;
	};
	const next = () => {
		if (step === 0 && !check(["parent_name", "contact_number"])) return;
		if (step === 1 && !check(["child_grade", "subject"])) return;
		setStep(step + 1);
	};
	const submit = async () => {
		const r = schema.safeParse(d);
		if (!r.success) return setErr(r.error.issues[0]?.message ?? "Please check your details");
		setBusy(true);
		try {
			if (!(await saveEnquiry({ data: r.data })).ok) {
				setErr("Something went wrong. Please try again or WhatsApp us.");
				return;
			}
			setErr("");
			setDone(true);
		} catch {
			setErr("Something went wrong. Please try again or WhatsApp us.");
		} finally {
			setBusy(false);
		}
	};
	if (done) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "glass glow-ring rounded-2xl p-8 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto grid h-14 w-14 place-items-center rounded-full bg-primary text-primary-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-4 text-2xl font-bold",
				children: "Enquiry received!"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-muted-foreground",
				children: [
					"We'll contact you shortly on ",
					d.contact_number,
					"."
				]
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "glass glow-ring rounded-2xl p-6 sm:p-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-6 flex gap-2",
				children: steps.map((s, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `h-1.5 rounded-full ${i <= step ? "bg-primary" : "bg-secondary"}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: `mt-2 text-xs ${i <= step ? "text-foreground" : "text-muted-foreground"}`,
						children: [
							i + 1,
							". ",
							s
						]
					})]
				}, s))
			}),
			step === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: field,
					placeholder: "Parent name",
					maxLength: 100,
					value: d.parent_name,
					onChange: (e) => set("parent_name", e.target.value)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					className: field,
					placeholder: "Contact number",
					type: "tel",
					maxLength: 20,
					value: d.contact_number,
					onChange: (e) => set("contact_number", e.target.value)
				})]
			}),
			step === 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: field,
					value: d.child_grade,
					onChange: (e) => set("child_grade", e.target.value),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "Child's grade"
					}), [
						4,
						5,
						6,
						7,
						8,
						9
					].map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", { children: ["Grade ", g] }, g))]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
					className: field,
					value: d.subject,
					onChange: (e) => set("subject", e.target.value),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "Subject needed"
					}), subjects.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: s.title }, s.key))]
				})]
			}),
			step === 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-2",
				children: ["No preference", ...tutors.map((t) => t.name)].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => set("preferred_tutor", n),
					className: `rounded-lg border px-3 py-3 text-sm transition ${d.preferred_tutor === n ? "border-primary bg-accent" : "border-input bg-secondary"}`,
					children: n
				}, n))
			}),
			err && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-destructive",
				children: err
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					disabled: step === 0,
					onClick: () => setStep(step - 1),
					className: "btn-ghost rounded-full px-5 py-3 text-sm disabled:opacity-30",
					children: "Back"
				}), step < 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: next,
					className: "btn-primary rounded-full px-6 py-3 text-sm font-semibold",
					children: "Next"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					disabled: busy,
					onClick: submit,
					className: "btn-primary rounded-full px-6 py-3 text-sm font-semibold",
					children: busy ? "Sending…" : "Send Enquiry"
				})]
			})
		]
	});
}
function Pricing() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-6xl px-5 py-20",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold uppercase tracking-widest text-glow",
					children: "Flexible Tutoring Rates"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-4 font-display text-7xl font-extrabold sm:text-9xl",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-chrome",
						children: "R60"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-2xl text-muted-foreground",
					children: "per hour · across all subjects"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 flex flex-wrap justify-center gap-3",
					children: [
						"1-on-1 Dedicated Tutor",
						"Curriculum Aligned (CAPS)",
						"Exam & Test Revision",
						"Pay only for lessons attended"
					].map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "glass flex items-center gap-2 rounded-full px-4 py-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4 text-glow" }), p]
					}, p))
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			id: "enquire",
			className: "mt-20 grid scroll-mt-24 gap-8 md:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-chrome mb-6 text-3xl font-bold",
				children: "Smart Enquiry Form"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InquiryForm, {})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-chrome mb-6 text-3xl font-bold",
				children: "Estimate Your Cost"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calculator, {})] })]
		})]
	});
}
//#endregion
export { Pricing as component };
