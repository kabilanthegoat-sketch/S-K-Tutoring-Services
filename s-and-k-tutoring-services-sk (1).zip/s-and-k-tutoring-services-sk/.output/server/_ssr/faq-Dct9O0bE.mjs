import { o as __toESM } from "../_runtime.mjs";
import { a as faqs } from "./site-data-z4f1HZ5K.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { l as ChevronDown, r as Receipt } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/faq-Dct9O0bE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Faq() {
	const [open, setOpen] = (0, import_react.useState)(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-3xl px-5 py-20",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-chrome text-center text-5xl font-extrabold",
				children: "Frequently Asked Questions"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "glass glow-ring mt-10 flex gap-4 rounded-2xl p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Receipt, { className: "h-6 w-6 shrink-0 text-glow" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Invoices are sent at the end of every month. Your monthly total is calculated dynamically based strictly on the number of lessons your child attended." })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 space-y-3",
				children: faqs.map((f, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `glass rounded-xl transition ${open === i ? "border-primary" : ""}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setOpen(open === i ? null : i),
						className: "flex w-full items-center justify-between gap-4 p-5 text-left font-semibold",
						children: [f.q, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: `h-5 w-5 shrink-0 transition ${open === i ? "rotate-180 text-glow" : ""}` })]
					}), open === i && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "px-5 pb-5 text-muted-foreground animate-in fade-in",
						children: f.a
					})]
				}, f.q))
			})
		]
	});
}
//#endregion
export { Faq as component };
