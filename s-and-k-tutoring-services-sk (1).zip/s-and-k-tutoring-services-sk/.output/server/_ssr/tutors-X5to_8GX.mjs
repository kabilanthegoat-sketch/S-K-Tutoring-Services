import { o as __toESM } from "../_runtime.mjs";
import { c as tutors } from "./site-data-z4f1HZ5K.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { a as Tilt } from "./Interactive-Cg8sMcil.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tutors-X5to_8GX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var filters = [
	"All",
	"Mathematics",
	"Physics",
	"English",
	"Afrikaans",
	"EMS",
	"Biology"
];
function Tutors() {
	const [f, setF] = (0, import_react.useState)("All");
	const shown = tutors.filter((t) => f === "All" || t.subjects.includes(f));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-6xl px-5 py-20",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-chrome text-center text-5xl font-extrabold",
				children: "Meet Our Expert Tutors"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mx-auto mt-4 max-w-xl text-center text-muted-foreground",
				children: "Academically strong, passionate, and dedicated to transforming your child's results."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 flex flex-wrap justify-center gap-2",
				children: filters.map((x) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setF(x),
					className: `rounded-full px-4 py-2 text-sm transition ${f === x ? "btn-primary" : "btn-ghost"}`,
					children: x === "All" ? "Show All Specialties" : x
				}, x))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4",
				children: shown.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tilt, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "glass h-full rounded-2xl p-6 text-center transition hover:glow-ring",
					children: [
						t.photo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: t.photo,
							alt: t.name,
							className: "mx-auto h-28 w-28 rounded-full object-cover ring-2 ring-primary"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mx-auto grid h-28 w-28 place-items-center rounded-full bg-accent font-display text-4xl font-bold ring-2 ring-primary",
							children: t.name[0]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-5 text-xl font-bold",
							children: t.name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-glow",
							children: t.role
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 flex flex-wrap justify-center gap-1.5",
							children: t.subjects.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "rounded-full border border-border bg-secondary px-2.5 py-1 text-xs",
								children: s
							}, s))
						})
					]
				}) }, t.name))
			})
		]
	});
}
//#endregion
export { Tutors as component };
