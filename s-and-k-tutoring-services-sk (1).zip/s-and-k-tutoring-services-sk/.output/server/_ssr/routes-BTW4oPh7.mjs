import { i as WHATSAPP_2 } from "./site-data-z4f1HZ5K.mjs";
import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { c as Gift, u as Check } from "../_libs/lucide-react.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Tilt, i as SubjectGrid, n as Reviews, r as Scene3D, t as Calculator } from "./Interactive-Cg8sMcil.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BTW4oPh7.js
var import_jsx_runtime = require_jsx_runtime();
var perks = [
	"Online & In-Person Lessons",
	"Personalised Support for Every Student",
	"Practice Activities Included",
	"Focus on Weak Areas",
	"Friendly, Patient & Results-Driven"
];
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "grid-bg relative overflow-hidden",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scene3D, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative mx-auto max-w-4xl px-5 py-24 text-center sm:py-36",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "inline-block rounded-full border border-primary bg-accent px-4 py-1 text-xs font-semibold uppercase tracking-widest",
						children: "Grades 4–9"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "text-chrome mt-6 text-5xl font-extrabold leading-[1.05] sm:text-7xl",
						children: ["Empowering Learners to ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-blue-glow",
							children: "Succeed"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mx-auto mt-6 max-w-xl text-lg text-muted-foreground",
						children: "Personalized 1-on-1 tutoring tailored to unlock every student's full potential."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-9 flex flex-wrap justify-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/pricing",
							hash: "enquire",
							className: "btn-primary rounded-full px-8 py-4 font-semibold",
							children: "Enquire Now"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/tutors",
							className: "btn-ghost rounded-full px-8 py-4 font-semibold",
							children: "Meet Our Tutors"
						})]
					})
				]
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "mx-auto max-w-6xl px-5",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "-mt-8 flex flex-wrap justify-center gap-2",
				children: perks.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "glass flex items-center gap-2 rounded-full px-4 py-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4 text-glow" }), p]
				}, p))
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "mx-auto mt-20 max-w-6xl px-5",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tilt, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "glass glow-ring relative overflow-hidden rounded-2xl p-8 sm:p-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-start gap-6 md:flex-row md:items-center md:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "flex items-center gap-2 text-sm font-semibold uppercase tracking-widest text-glow",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gift, { className: "h-4 w-4" }), "Refer A Student Program"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-2 text-3xl font-bold sm:text-4xl",
							children: "Together We Grow. Together We Succeed."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-muted-foreground",
							children: [
								"Refer a friend and ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
									className: "text-foreground",
									children: "you get 20% OFF"
								}),
								" next month's tutoring."
							]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: `https://wa.me/${WHATSAPP_2}?text=${encodeURIComponent("Hi! I'd like to refer a friend to S&K Tutoring.")}`,
						target: "_blank",
						rel: "noreferrer",
						className: "btn-primary shrink-0 rounded-full px-7 py-4 font-semibold",
						children: "Refer a Friend Now"
					})]
				})
			}) })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto mt-24 max-w-6xl px-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-chrome text-center text-4xl font-bold",
					children: "Subjects & Services Offered"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-center text-muted-foreground",
					children: "Click on any subject card below to view detailed lesson summaries!"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 text-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/subjects",
						className: "btn-ghost inline-flex rounded-full px-5 py-2 text-sm font-semibold",
						children: "Explore Subjects & Services"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubjectGrid, {})
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto mt-24 grid max-w-6xl gap-10 px-5 md:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-chrome text-4xl font-bold",
					children: "Who We Are"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-5 text-muted-foreground",
					children: [
						"S&K Tutoring is an energetic, results-driven educational service run by a team of academically strong students who are truly passionate about helping others succeed. We specialize in personalized academic support designed for learners in ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
							className: "text-foreground",
							children: "Grades 4 through 9"
						}),
						"."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-muted-foreground",
					children: "By breaking down the curriculum into manageable, easily digestible concepts, our tutors create a friendly, patient, and motivating environment where students don't just memorize information—they master it."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 rounded-xl border-l-4 border-primary bg-accent p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display font-semibold",
						children: "Our Mission"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted-foreground",
						children: "To identify individual weak areas, transform them into strengths, and provide every child with the tools, practice activities, and confidence they need to excel in school."
					})]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calculator, {})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-24",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-chrome text-center text-4xl font-bold",
					children: "What Parents & Students Say"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-center text-muted-foreground",
					children: "Read real feedback or leave your own review below!"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 text-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/reviews",
						className: "btn-ghost inline-flex rounded-full px-5 py-2 text-sm font-semibold",
						children: "Open Reviews Page"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto mt-10 max-w-6xl px-5",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reviews, {})
				})
			]
		})
	] });
}
//#endregion
export { Home as component };
