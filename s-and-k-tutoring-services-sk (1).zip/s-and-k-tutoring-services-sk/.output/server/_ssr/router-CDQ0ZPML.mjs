import { o as __toESM } from "../_runtime.mjs";
import { i as WHATSAPP_2, n as INSTAGRAM, r as LOGO, t as EMAIL } from "./site-data-z4f1HZ5K.mjs";
import { n as require_jsx_runtime, r as require_react, t as QueryClientProvider } from "../_libs/react+tanstack__react-query.mjs";
import { a as Menu, i as MessageCircle, o as Mail, s as Instagram, t as X } from "../_libs/lucide-react.mjs";
import { _ as createFileRoute, b as useRouter, d as Scripts, f as HeadContent, g as lazyRouteComponent, h as Outlet, m as createRouter, v as createRootRouteWithContext, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-CDQ0ZPML.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-DiuHTGSX.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const message = error instanceof Response ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}` : error instanceof Error ? error.message : String(error);
	const stack = error instanceof Error ? error.stack : void 0;
	window.__lovableReportRuntimeError?.({
		message,
		...stack !== void 0 && { stack },
		filename: window.location.pathname
	});
}
var links = [
	{
		to: "/",
		label: "Home"
	},
	{
		to: "/subjects",
		label: "Subjects"
	},
	{
		to: "/tutors",
		label: "Tutors"
	},
	{
		to: "/pricing",
		label: "Pricing & Enquire"
	},
	{
		to: "/reviews",
		label: "Reviews"
	},
	{
		to: "/faq",
		label: "FAQ & Payments"
	}
];
function Header() {
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur-xl",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl grid-cols-[minmax(0,1fr)_auto] items-center gap-4 px-5 py-3 md:flex md:justify-between",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "flex min-w-0 items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: LOGO,
						alt: "S&K Tutoring logo",
						className: "h-10 w-10 shrink-0 rounded-full object-cover ring-1 ring-primary"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "truncate font-display text-lg font-bold",
						children: "S&K Tutoring"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "hidden items-center gap-0 xl:flex",
					children: [links.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: l.to,
						className: "rounded-full px-2 py-2 text-sm text-muted-foreground transition hover:text-foreground",
						activeProps: { className: "!text-foreground bg-accent ring-1 ring-primary" },
						activeOptions: { exact: true },
						children: l.label
					}, l.to)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/pricing",
						hash: "enquire",
						className: "btn-primary ml-2 rounded-full px-5 py-2 text-sm font-semibold",
						children: "Enquire Now"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "xl:hidden",
					"aria-label": "Menu",
					onClick: () => setOpen(!open),
					children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, {})
				})
			]
		}), open && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "flex flex-col gap-1 border-t border-border px-5 py-3 xl:hidden",
			children: links.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: l.to,
				onClick: () => setOpen(false),
				className: "rounded-lg px-3 py-3 text-muted-foreground",
				activeProps: { className: "!text-foreground bg-accent" },
				activeOptions: { exact: true },
				children: l.label
			}, l.to))
		})]
	});
}
function Footer() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		className: "mt-24 border-t border-border",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl gap-6 px-5 py-10 text-sm text-muted-foreground md:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-lg font-bold text-foreground",
					children: "S&K Tutoring Services"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2",
					children: "Empowering learners in Grades 4–9 to succeed."
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-semibold text-foreground",
						children: "Contact Us"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						className: "mt-2 flex items-center gap-2 hover:text-glow",
						href: `https://wa.me/${WHATSAPP_2}?text=${encodeURIComponent("Hi S&K Tutoring, I'd like to enquire about lessons.")}`,
						target: "_blank",
						rel: "noopener noreferrer",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "h-4 w-4" }), "063 845 2735"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						className: "mt-2 flex items-center gap-2 break-all hover:text-glow",
						href: `mailto:${EMAIL}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-4 w-4 shrink-0" }), EMAIL]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						className: "mt-2 flex items-center gap-2 hover:text-glow",
						href: `https://instagram.com/${INSTAGRAM}`,
						target: "_blank",
						rel: "noreferrer",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Instagram, { className: "h-4 w-4 shrink-0" }),
							"@",
							INSTAGRAM
						]
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "md:text-right",
					children: [
						"\"Let's achieve your goals together! ❤️\"",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
						"© ",
						(/* @__PURE__ */ new Date()).getFullYear(),
						" S&K Tutoring"
					]
				})
			]
		})
	});
}
function WhatsAppFab() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		href: `https://wa.me/${WHATSAPP_2}?text=${encodeURIComponent("Hi S&K Tutoring, I'd like to enquire about lessons.")}`,
		target: "_blank",
		rel: "noreferrer",
		"aria-label": "Chat on WhatsApp",
		className: "btn-primary fixed bottom-5 right-5 z-50 grid h-14 w-14 place-items-center rounded-full",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, { className: "h-7 w-7" })
	});
}
function SplashScreen() {
	const [exiting, setExiting] = (0, import_react.useState)(false);
	const [visible, setVisible] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		const exitTimer = window.setTimeout(() => setExiting(true), 650);
		const removeTimer = window.setTimeout(() => setVisible(false), 1050);
		return () => {
			window.clearTimeout(exitTimer);
			window.clearTimeout(removeTimer);
		};
	}, []);
	if (!visible) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		role: "status",
		"aria-label": "Loading S&K Tutoring",
		"data-exiting": exiting,
		className: `fixed inset-0 z-[100] grid place-items-center bg-background transition-opacity duration-300 ${exiting ? "splash-exiting" : "opacity-100"}`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "px-6 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: LOGO,
					alt: "",
					className: "mx-auto h-24 w-24 rounded-full object-cover ring-2 ring-primary shadow-[0_0_45px_oklch(0.6_0.23_258_/_0.45)]"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-5 text-2xl font-extrabold tracking-tight text-chrome",
					children: "S&K Tutoring"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Empowering learners to succeed"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto mt-6 h-1 w-24 overflow-hidden rounded-full bg-secondary",
					"aria-hidden": "true",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "splash-progress h-full w-1/2 rounded-full bg-primary shadow-[0_0_16px_var(--glow)]" })
				})
			]
		})
	});
}
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$6 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "S&K Tutoring Services" },
			{
				name: "description",
				content: "Personalised 1-on-1 tutoring for Grades 4–9."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700&family=Sora:wght@600;700;800&display=swap"
			},
			{
				rel: "icon",
				href: "https://i.postimg.cc/dtW3NT4b/SK-LOGO-jpeg.jpg"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$6.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QueryClientProvider, {
		client: queryClient,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SplashScreen, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footer, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatsAppFab, {})
		]
	});
}
var $$splitComponentImporter$5 = () => import("./routes-BTW4oPh7.mjs");
var Route$5 = createFileRoute("/")({
	head: () => ({ meta: [
		{ title: "S&K Tutoring Services — Empowering Learners to Succeed" },
		{
			name: "description",
			content: "Personalised 1-on-1 tutoring for Grades 4–9. Flat rate of R60 per hour, online and in-person."
		},
		{
			property: "og:title",
			content: "S&K Tutoring Services — Empowering Learners to Succeed"
		},
		{
			property: "og:description",
			content: "Personalised 1-on-1 tutoring for Grades 4–9 at R60 per hour."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./faq-Dct9O0bE.mjs");
var Route$4 = createFileRoute("/faq")({
	head: () => ({ meta: [
		{ title: "FAQ & Payments — S&K Tutoring" },
		{
			name: "description",
			content: "How lessons, invoices and monthly payments work at S&K Tutoring."
		},
		{
			property: "og:title",
			content: "FAQ & Payments — S&K Tutoring"
		},
		{
			property: "og:description",
			content: "Answers about lessons, invoices and payments."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./pricing-CQoSx_BD.mjs");
var Route$3 = createFileRoute("/pricing")({
	head: () => ({ meta: [
		{ title: "Pricing & Enquiries — S&K Tutoring" },
		{
			name: "description",
			content: "One flat rate: R60 per hour across all subjects. Send an enquiry in under a minute."
		},
		{
			property: "og:title",
			content: "Pricing & Enquiries — S&K Tutoring"
		},
		{
			property: "og:description",
			content: "R60 per hour, all subjects, Grades 4–9."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./reviews-CZdvsh-o.mjs");
var Route$2 = createFileRoute("/reviews")({
	head: () => ({ meta: [
		{ title: "Reviews — S&K Tutoring" },
		{
			name: "description",
			content: "Read feedback from S&K Tutoring families and share your own review."
		},
		{
			property: "og:title",
			content: "Reviews — S&K Tutoring"
		},
		{
			property: "og:description",
			content: "Read feedback from S&K Tutoring families and share your own review."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./subjects-flXinp8k.mjs");
var Route$1 = createFileRoute("/subjects")({
	head: () => ({ meta: [
		{ title: "Subjects & Services — S&K Tutoring" },
		{
			name: "description",
			content: "Explore S&K Tutoring subjects and learning support for Grades 4–9."
		},
		{
			property: "og:title",
			content: "Subjects & Services — S&K Tutoring"
		},
		{
			property: "og:description",
			content: "Explore subjects and personalised learning support for Grades 4–9."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./tutors-X5to_8GX.mjs");
var Route = createFileRoute("/tutors")({
	head: () => ({ meta: [
		{ title: "Meet Our Expert Tutors — S&K Tutoring" },
		{
			name: "description",
			content: "Meet Kabilan, Shriyans, Achuma and Luke — S&K Tutoring's passionate Grades 4–9 tutors."
		},
		{
			property: "og:title",
			content: "Meet Our Expert Tutors — S&K Tutoring"
		},
		{
			property: "og:description",
			content: "Academically strong, passionate tutors for Grades 4–9."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var rootRouteChildren = {
	IndexRoute: Route$5.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$6
	}),
	FaqRoute: Route$4.update({
		id: "/faq",
		path: "/faq",
		getParentRoute: () => Route$6
	}),
	PricingRoute: Route$3.update({
		id: "/pricing",
		path: "/pricing",
		getParentRoute: () => Route$6
	}),
	ReviewsRoute: Route$2.update({
		id: "/reviews",
		path: "/reviews",
		getParentRoute: () => Route$6
	}),
	SubjectsRoute: Route$1.update({
		id: "/subjects",
		path: "/subjects",
		getParentRoute: () => Route$6
	}),
	TutorsRoute: Route.update({
		id: "/tutors",
		path: "/tutors",
		getParentRoute: () => Route$6
	})
};
var routeTree = Route$6._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
