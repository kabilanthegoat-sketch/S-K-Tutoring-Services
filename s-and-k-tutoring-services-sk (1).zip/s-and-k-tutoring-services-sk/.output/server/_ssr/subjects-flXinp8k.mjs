import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { i as SubjectGrid } from "./Interactive-Cg8sMcil.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/subjects-flXinp8k.js
var import_jsx_runtime = require_jsx_runtime();
function SubjectsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-6xl px-5 py-20",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "mx-auto max-w-2xl text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold uppercase tracking-widest text-glow",
					children: "Grades 4–9"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-chrome mt-3 text-5xl font-extrabold",
					children: "Subjects & Services"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-muted-foreground",
					children: "Choose a subject or service to see the skills and topics our tutors can help your learner build."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-12",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubjectGrid, {})
		})]
	});
}
//#endregion
export { SubjectsPage as component };
