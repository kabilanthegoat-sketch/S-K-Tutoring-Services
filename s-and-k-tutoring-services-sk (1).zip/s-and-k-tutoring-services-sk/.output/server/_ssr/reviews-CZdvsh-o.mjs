import { n as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as Reviews } from "./Interactive-Cg8sMcil.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reviews-CZdvsh-o.js
var import_jsx_runtime = require_jsx_runtime();
function ReviewsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-6xl px-5 py-20",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "mx-auto max-w-2xl text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold uppercase tracking-widest text-glow",
					children: "Family feedback"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-chrome mt-3 text-5xl font-extrabold",
					children: "Reviews"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-muted-foreground",
					children: "Read what parents and students say, or share your experience with S&K Tutoring."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-12",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Reviews, {})
		})]
	});
}
//#endregion
export { ReviewsPage as component };
