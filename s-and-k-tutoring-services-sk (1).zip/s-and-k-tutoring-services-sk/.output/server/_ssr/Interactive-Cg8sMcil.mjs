import { o as __toESM } from "../_runtime.mjs";
import { o as staticReviews, s as subjects } from "./site-data-z4f1HZ5K.mjs";
import { n as require_jsx_runtime, r as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { n as Star, t as X } from "../_libs/lucide-react.mjs";
import { t as supabase } from "./client-gcDsbCnO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/Interactive-Cg8sMcil.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Tilt({ children, className = "" }) {
	const ref = (0, import_react.useRef)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		style: { perspective: 900 },
		className,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			ref,
			className: "h-full transition-transform duration-200 ease-out",
			style: { transformStyle: "preserve-3d" },
			onMouseMove: (e) => {
				const r = e.currentTarget.getBoundingClientRect();
				const x = (e.clientX - r.left) / r.width - .5, y = (e.clientY - r.top) / r.height - .5;
				e.currentTarget.style.transform = `rotateY(${x * 14}deg) rotateX(${-y * 14}deg) translateZ(10px)`;
			},
			onMouseLeave: (e) => e.currentTarget.style.transform = "",
			children
		})
	});
}
function Cube({ size, silver, className }) {
	const h = size / 2;
	const faces = [
		`translateZ(${h}px)`,
		`rotateY(180deg) translateZ(${h}px)`,
		`rotateY(90deg) translateZ(${h}px)`,
		`rotateY(-90deg) translateZ(${h}px)`,
		`rotateX(90deg) translateZ(${h}px)`,
		`rotateX(-90deg) translateZ(${h}px)`
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: `absolute animate-floaty ${className}`,
		style: {
			width: size,
			height: size
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "relative h-full w-full animate-spin3d",
			children: faces.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `cube-face rounded-md ${silver ? "silver" : ""}`,
				style: { transform: t }
			}, t))
		})
	});
}
function Scene3D() {
	const [p, setP] = (0, import_react.useState)({
		x: 0,
		y: 0
	});
	(0, import_react.useEffect)(() => {
		const f = (e) => setP({
			x: e.clientX / window.innerWidth - .5,
			y: e.clientY / window.innerHeight - .5
		});
		window.addEventListener("mousemove", f);
		return () => window.removeEventListener("mousemove", f);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		"aria-hidden": true,
		className: "pointer-events-none absolute inset-0 overflow-hidden",
		style: { perspective: 1e3 },
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "absolute inset-0 transition-transform duration-300 ease-out",
			style: {
				transformStyle: "preserve-3d",
				transform: `rotateY(${p.x * 20}deg) rotateX(${-p.y * 20}deg)`
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cube, {
					size: 110,
					className: "right-[8%] top-[14%]"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cube, {
					size: 60,
					silver: true,
					className: "left-[6%] top-[22%] [animation-delay:-2s]"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cube, {
					size: 80,
					className: "bottom-[14%] left-[14%] [animation-delay:-4s]"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cube, {
					size: 44,
					silver: true,
					className: "bottom-[22%] right-[18%] [animation-delay:-1s]"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cube, {
					size: 34,
					className: "right-[38%] top-[8%] [animation-delay:-3s]"
				})
			]
		})
	});
}
function SubjectGrid() {
	const [sel, setSel] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4",
		children: subjects.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tilt, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			onClick: () => setSel(s),
			className: "glass h-full w-full rounded-xl p-5 text-left transition hover:glow-ring",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display font-semibold",
					children: s.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted-foreground",
					children: s.tag
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-xs font-semibold text-glow",
					children: "Click for more info →"
				})
			]
		}) }, s.key))
	}), sel && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "fixed inset-0 z-50 grid place-items-center bg-background/80 p-5 backdrop-blur",
		onClick: () => setSel(null),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "glass glow-ring relative w-full max-w-md rounded-2xl p-7 animate-in zoom-in-95",
			onClick: (e) => e.stopPropagation(),
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "absolute right-4 top-4 text-muted-foreground",
					onClick: () => setSel(null),
					"aria-label": "Close",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold uppercase tracking-widest text-glow",
					children: sel.grade
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-2 text-2xl font-bold",
					children: sel.title
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-muted-foreground",
					children: sel.description
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-5 grid grid-cols-2 gap-2",
					children: sel.focus.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "rounded-lg border border-primary/50 bg-accent px-3 py-2 text-sm",
						children: f
					}, f))
				})
			]
		})
	})] });
}
function Calculator() {
	const [hours, setHours] = (0, import_react.useState)(1);
	const [perWeek, setPerWeek] = (0, import_react.useState)(2);
	const session = hours * 60;
	const month = session * perWeek * 4;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "glass glow-ring rounded-2xl p-6 sm:p-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-2xl font-bold",
				children: "Lesson Cost Calculator"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-muted-foreground",
				children: ["1 hour session = R", 60]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-6 block text-sm",
				children: [
					"Hours per session: ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
						className: "text-glow",
						children: hours
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "range",
						min: .5,
						max: 3,
						step: .5,
						value: hours,
						onChange: (e) => setHours(+e.target.value),
						className: "mt-2 w-full accent-[var(--color-primary)]"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "mt-4 block text-sm",
				children: [
					"Sessions per week: ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
						className: "text-glow",
						children: perWeek
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "range",
						min: 1,
						max: 7,
						value: perWeek,
						onChange: (e) => setPerWeek(+e.target.value),
						className: "mt-2 w-full accent-[var(--color-primary)]"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid grid-cols-2 gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl bg-secondary p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Per session"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-display text-2xl font-bold",
						children: ["R", session]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl border border-primary bg-accent p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Est. per month"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-display text-2xl font-bold text-glow",
						children: ["R", month]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-xs text-muted-foreground",
				children: "Estimate based on 4 weeks. You're only billed for lessons attended."
			})
		]
	});
}
function Reviews() {
	const [list, setList] = (0, import_react.useState)(staticReviews);
	const [form, setForm] = (0, import_react.useState)({
		name: "",
		comment: "",
		rating: 5
	});
	const [msg, setMsg] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		supabase.from("reviews").select("name,rating,comment").order("created_at", { ascending: false }).limit(30).then(({ data }) => data && setList([...data, ...staticReviews]));
	}, []);
	const submit = async (e) => {
		e.preventDefault();
		const name = form.name.trim(), comment = form.comment.trim();
		if (!name || name.length > 60 || !comment || comment.length > 500) return setMsg("Please add your name and a review (max 500 characters).");
		const { error } = await supabase.from("reviews").insert({
			name,
			comment,
			rating: form.rating
		});
		if (error) return setMsg("Couldn't post your review. Please try again.");
		setList([{
			name,
			comment,
			rating: form.rating
		}, ...list]);
		setForm({
			name: "",
			comment: "",
			rating: 5
		});
		setMsg("Thank you! Your review is live.");
	};
	const row = [...list, ...list];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "overflow-hidden [mask-image:linear-gradient(90deg,transparent,black_10%,black_90%,transparent)]",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex w-max gap-4 animate-marquee",
			children: row.map((r, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
				className: "glass w-80 shrink-0 rounded-xl p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex text-glow",
						children: Array.from({ length: r.rating }).map((_, j) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "h-4 w-4 fill-current" }, j))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", {
						className: "mt-3 text-sm",
						children: [
							"\"",
							r.comment,
							"\""
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
						className: "mt-3 text-sm font-semibold text-muted-foreground",
						children: ["— ", r.name]
					})
				]
			}, i))
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		onSubmit: submit,
		className: "glass mx-auto mt-10 max-w-xl rounded-2xl p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "text-xl font-bold",
				children: "Leave a Review"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex items-center gap-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mr-2 text-sm text-muted-foreground",
					children: "Your Rating:"
				}), [
					1,
					2,
					3,
					4,
					5
				].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setForm({
						...form,
						rating: n
					}),
					"aria-label": `${n} stars`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: `h-6 w-6 ${n <= form.rating ? "fill-current text-glow" : "text-muted-foreground"}` })
				}, n))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				maxLength: 60,
				placeholder: "Your name",
				value: form.name,
				onChange: (e) => setForm({
					...form,
					name: e.target.value
				}),
				className: "mt-4 w-full rounded-lg border border-input bg-secondary px-4 py-3 outline-none focus:border-primary"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
				maxLength: 500,
				rows: 3,
				placeholder: "Your review",
				value: form.comment,
				onChange: (e) => setForm({
					...form,
					comment: e.target.value
				}),
				className: "mt-3 w-full rounded-lg border border-input bg-secondary px-4 py-3 outline-none focus:border-primary"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "btn-primary mt-4 rounded-full px-6 py-3 font-semibold",
				children: "Submit Review"
			}),
			msg && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted-foreground",
				children: msg
			})
		]
	})] });
}
//#endregion
export { Tilt as a, SubjectGrid as i, Reviews as n, Scene3D as r, Calculator as t };
