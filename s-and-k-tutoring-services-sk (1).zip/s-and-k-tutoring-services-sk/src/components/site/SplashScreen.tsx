import { useEffect, useState } from "react";
import { LOGO } from "@/lib/site-data";

export function SplashScreen() {
  const [exiting, setExiting] = useState(false);
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    const exitTimer = window.setTimeout(() => setExiting(true), 650);
    const removeTimer = window.setTimeout(() => setVisible(false), 1_050);

    return () => {
      window.clearTimeout(exitTimer);
      window.clearTimeout(removeTimer);
    };
  }, []);

  if (!visible) return null;

  return (
    <div
      role="status"
      aria-label="Loading S&K Tutoring"
      data-exiting={exiting}
      className={`fixed inset-0 z-[100] grid place-items-center bg-background transition-opacity duration-300 ${exiting ? "splash-exiting" : "opacity-100"}`}
    >
      <div className="px-6 text-center">
        <img
          src={LOGO}
          alt=""
          className="mx-auto h-24 w-24 rounded-full object-cover ring-2 ring-primary shadow-[0_0_45px_oklch(0.6_0.23_258_/_0.45)]"
        />
        <h1 className="mt-5 text-2xl font-extrabold tracking-tight text-chrome">
          S&amp;K Tutoring
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">Empowering learners to succeed</p>
        <div
          className="mx-auto mt-6 h-1 w-24 overflow-hidden rounded-full bg-secondary"
          aria-hidden="true"
        >
          <div className="splash-progress h-full w-1/2 rounded-full bg-primary shadow-[0_0_16px_var(--glow)]" />
        </div>
      </div>
    </div>
  );
}
