import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { Menu, X, Mail, MessageCircle, Instagram } from "lucide-react";
import { EMAIL, LOGO, WHATSAPP_2, INSTAGRAM } from "@/lib/site-data";

const links = [
  { to: "/", label: "Home" },
  { to: "/subjects", label: "Subjects" },
  { to: "/tutors", label: "Tutors" },
  { to: "/pricing", label: "Pricing & Enquire" },
  { to: "/reviews", label: "Reviews" },
  { to: "/faq", label: "FAQ & Payments" },
] as const;

export function Header() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur-xl">
      <div className="mx-auto grid max-w-6xl grid-cols-[minmax(0,1fr)_auto] items-center gap-4 px-5 py-3 md:flex md:justify-between">
        <Link to="/" className="flex min-w-0 items-center gap-3">
          <img src={LOGO} alt="S&K Tutoring logo" className="h-10 w-10 shrink-0 rounded-full object-cover ring-1 ring-primary" />
          <span className="truncate font-display text-lg font-bold">S&amp;K Tutoring</span>
        </Link>
        <nav className="hidden items-center gap-0 xl:flex">
          {links.map((l) => (
            <Link key={l.to} to={l.to} className="rounded-full px-2 py-2 text-sm text-muted-foreground transition hover:text-foreground"
              activeProps={{ className: "!text-foreground bg-accent ring-1 ring-primary" }} activeOptions={{ exact: true }}>
              {l.label}
            </Link>
          ))}
          <Link to="/pricing" hash="enquire" className="btn-primary ml-2 rounded-full px-5 py-2 text-sm font-semibold">Enquire Now</Link>
        </nav>
        <button className="xl:hidden" aria-label="Menu" onClick={() => setOpen(!open)}>{open ? <X /> : <Menu />}</button>
      </div>
      {open && (
        <nav className="flex flex-col gap-1 border-t border-border px-5 py-3 xl:hidden">
          {links.map((l) => (
            <Link key={l.to} to={l.to} onClick={() => setOpen(false)} className="rounded-lg px-3 py-3 text-muted-foreground"
              activeProps={{ className: "!text-foreground bg-accent" }} activeOptions={{ exact: true }}>{l.label}</Link>
          ))}
        </nav>
      )}
    </header>
  );
}

export function Footer() {
  return (
    <footer className="mt-24 border-t border-border">
      <div className="mx-auto grid max-w-6xl gap-6 px-5 py-10 text-sm text-muted-foreground md:grid-cols-3">
        <div>
          <p className="font-display text-lg font-bold text-foreground">S&amp;K Tutoring Services</p>
          <p className="mt-2">Empowering learners in Grades 4–9 to succeed.</p>
        </div>
        <div>
          <p className="font-semibold text-foreground">Contact Us</p>
          <a className="mt-2 flex items-center gap-2 hover:text-glow" href={`https://wa.me/${WHATSAPP_2}?text=${encodeURIComponent("Hi S&K Tutoring, I'd like to enquire about lessons.")}`} target="_blank" rel="noopener noreferrer"><MessageCircle className="h-4 w-4" />063 845 2735</a>
          <a className="mt-2 flex items-center gap-2 break-all hover:text-glow" href={`mailto:${EMAIL}`}><Mail className="h-4 w-4 shrink-0" />{EMAIL}</a>
          <a className="mt-2 flex items-center gap-2 hover:text-glow" href={`https://instagram.com/${INSTAGRAM}`} target="_blank" rel="noreferrer"><Instagram className="h-4 w-4 shrink-0" />@{INSTAGRAM}</a>
        </div>
        <p className="md:text-right">"Let's achieve your goals together! ❤️"<br />© {new Date().getFullYear()} S&amp;K Tutoring</p>
      </div>
    </footer>
  );
}

export function WhatsAppFab() {
  return (
    <a href={`https://wa.me/${WHATSAPP_2}?text=${encodeURIComponent("Hi S&K Tutoring, I'd like to enquire about lessons.")}`}
      target="_blank" rel="noreferrer" aria-label="Chat on WhatsApp"
      className="btn-primary fixed bottom-5 right-5 z-50 grid h-14 w-14 place-items-center rounded-full">
      <MessageCircle className="h-7 w-7" />
    </a>
  );
}
