import { useEffect, useRef, useState, type ReactNode } from "react";
import { Star, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { RATE, staticReviews, subjects, type Subject } from "@/lib/site-data";

/* 3D tilt card */
export function Tilt({ children, className = "" }: { children: ReactNode; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  return (
    <div style={{ perspective: 900 }} className={className}>
      <div ref={ref} className="h-full transition-transform duration-200 ease-out" style={{ transformStyle: "preserve-3d" }}
        onMouseMove={(e) => {
          const r = e.currentTarget.getBoundingClientRect();
          const x = (e.clientX - r.left) / r.width - 0.5, y = (e.clientY - r.top) / r.height - 0.5;
          e.currentTarget.style.transform = `rotateY(${x * 14}deg) rotateX(${-y * 14}deg) translateZ(10px)`;
        }}
        onMouseLeave={(e) => (e.currentTarget.style.transform = "")}>
        {children}
      </div>
    </div>
  );
}

function Cube({ size, silver, className }: { size: number; silver?: boolean; className: string }) {
  const h = size / 2;
  const faces = [`translateZ(${h}px)`, `rotateY(180deg) translateZ(${h}px)`, `rotateY(90deg) translateZ(${h}px)`, `rotateY(-90deg) translateZ(${h}px)`, `rotateX(90deg) translateZ(${h}px)`, `rotateX(-90deg) translateZ(${h}px)`];
  return (
    <div className={`absolute animate-floaty ${className}`} style={{ width: size, height: size }}>
      <div className="relative h-full w-full animate-spin3d">
        {faces.map((t) => <div key={t} className={`cube-face rounded-md ${silver ? "silver" : ""}`} style={{ transform: t }} />)}
      </div>
    </div>
  );
}

/* Floating 3D scene that follows the mouse */
export function Scene3D() {
  const [p, setP] = useState({ x: 0, y: 0 });
  useEffect(() => {
    const f = (e: MouseEvent) => setP({ x: e.clientX / window.innerWidth - 0.5, y: e.clientY / window.innerHeight - 0.5 });
    window.addEventListener("mousemove", f);
    return () => window.removeEventListener("mousemove", f);
  }, []);
  return (
    <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden" style={{ perspective: 1000 }}>
      <div className="absolute inset-0 transition-transform duration-300 ease-out" style={{ transformStyle: "preserve-3d", transform: `rotateY(${p.x * 20}deg) rotateX(${-p.y * 20}deg)` }}>
        <Cube size={110} className="right-[8%] top-[14%]" />
        <Cube size={60} silver className="left-[6%] top-[22%] [animation-delay:-2s]" />
        <Cube size={80} className="bottom-[14%] left-[14%] [animation-delay:-4s]" />
        <Cube size={44} silver className="bottom-[22%] right-[18%] [animation-delay:-1s]" />
        <Cube size={34} className="right-[38%] top-[8%] [animation-delay:-3s]" />
      </div>
    </div>
  );
}

/* Subjects with detail modal */
export function SubjectGrid() {
  const [sel, setSel] = useState<Subject | null>(null);
  return (
    <>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
        {subjects.map((s) => (
          <Tilt key={s.key}>
            <button onClick={() => setSel(s)} className="glass h-full w-full rounded-xl p-5 text-left transition hover:glow-ring">
              <p className="font-display font-semibold">{s.title}</p>
              <p className="mt-1 text-sm text-muted-foreground">{s.tag}</p>
              <p className="mt-3 text-xs font-semibold text-glow">Click for more info →</p>
            </button>
          </Tilt>
        ))}
      </div>
      {sel && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-background/80 p-5 backdrop-blur" onClick={() => setSel(null)}>
          <div className="glass glow-ring relative w-full max-w-md rounded-2xl p-7 animate-in zoom-in-95" onClick={(e) => e.stopPropagation()}>
            <button className="absolute right-4 top-4 text-muted-foreground" onClick={() => setSel(null)} aria-label="Close"><X /></button>
            <p className="text-xs font-semibold uppercase tracking-widest text-glow">{sel.grade}</p>
            <h3 className="mt-2 text-2xl font-bold">{sel.title}</h3>
            <p className="mt-3 text-muted-foreground">{sel.description}</p>
            <ul className="mt-5 grid grid-cols-2 gap-2">
              {sel.focus.map((f) => <li key={f} className="rounded-lg border border-primary/50 bg-accent px-3 py-2 text-sm">{f}</li>)}
            </ul>
          </div>
        </div>
      )}
    </>
  );
}

/* Price calculator */
export function Calculator() {
  const [hours, setHours] = useState(1);
  const [perWeek, setPerWeek] = useState(2);
  const session = hours * RATE;
  const month = session * perWeek * 4;
  return (
    <div className="glass glow-ring rounded-2xl p-6 sm:p-8">
      <h3 className="text-2xl font-bold">Lesson Cost Calculator</h3>
      <p className="mt-1 text-sm text-muted-foreground">1 hour session = R{RATE}</p>
      <label className="mt-6 block text-sm">Hours per session: <b className="text-glow">{hours}</b>
        <input type="range" min={0.5} max={3} step={0.5} value={hours} onChange={(e) => setHours(+e.target.value)} className="mt-2 w-full accent-[var(--color-primary)]" />
      </label>
      <label className="mt-4 block text-sm">Sessions per week: <b className="text-glow">{perWeek}</b>
        <input type="range" min={1} max={7} value={perWeek} onChange={(e) => setPerWeek(+e.target.value)} className="mt-2 w-full accent-[var(--color-primary)]" />
      </label>
      <div className="mt-6 grid grid-cols-2 gap-3">
        <div className="rounded-xl bg-secondary p-4"><p className="text-xs text-muted-foreground">Per session</p><p className="font-display text-2xl font-bold">R{session}</p></div>
        <div className="rounded-xl border border-primary bg-accent p-4"><p className="text-xs text-muted-foreground">Est. per month</p><p className="font-display text-2xl font-bold text-glow">R{month}</p></div>
      </div>
      <p className="mt-3 text-xs text-muted-foreground">Estimate based on 4 weeks. You're only billed for lessons attended.</p>
    </div>
  );
}

/* Reviews marquee + submit form */
type Review = { name: string; rating: number; comment: string };
export function Reviews() {
  const [list, setList] = useState<Review[]>(staticReviews);
  const [form, setForm] = useState({ name: "", comment: "", rating: 5 });
  const [msg, setMsg] = useState("");
  useEffect(() => {
    supabase.from("reviews").select("name,rating,comment").order("created_at", { ascending: false }).limit(30)
      .then(({ data }) => data && setList([...data, ...staticReviews]));
  }, []);
  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const name = form.name.trim(), comment = form.comment.trim();
    if (!name || name.length > 60 || !comment || comment.length > 500) return setMsg("Please add your name and a review (max 500 characters).");
    const { error } = await supabase.from("reviews").insert({ name, comment, rating: form.rating });
    if (error) return setMsg("Couldn't post your review. Please try again.");
    setList([{ name, comment, rating: form.rating }, ...list]);
    setForm({ name: "", comment: "", rating: 5 });
    setMsg("Thank you! Your review is live.");
  };
  const row = [...list, ...list];
  return (
    <div>
      <div className="overflow-hidden [mask-image:linear-gradient(90deg,transparent,black_10%,black_90%,transparent)]">
        <div className="flex w-max gap-4 animate-marquee">
          {row.map((r, i) => (
            <figure key={i} className="glass w-80 shrink-0 rounded-xl p-5">
              <div className="flex text-glow">{Array.from({ length: r.rating }).map((_, j) => <Star key={j} className="h-4 w-4 fill-current" />)}</div>
              <blockquote className="mt-3 text-sm">"{r.comment}"</blockquote>
              <figcaption className="mt-3 text-sm font-semibold text-muted-foreground">— {r.name}</figcaption>
            </figure>
          ))}
        </div>
      </div>
      <form onSubmit={submit} className="glass mx-auto mt-10 max-w-xl rounded-2xl p-6">
        <h3 className="text-xl font-bold">Leave a Review</h3>
        <div className="mt-4 flex items-center gap-1">
          <span className="mr-2 text-sm text-muted-foreground">Your Rating:</span>
          {[1, 2, 3, 4, 5].map((n) => (
            <button type="button" key={n} onClick={() => setForm({ ...form, rating: n })} aria-label={`${n} stars`}>
              <Star className={`h-6 w-6 ${n <= form.rating ? "fill-current text-glow" : "text-muted-foreground"}`} />
            </button>
          ))}
        </div>
        <input maxLength={60} placeholder="Your name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="mt-4 w-full rounded-lg border border-input bg-secondary px-4 py-3 outline-none focus:border-primary" />
        <textarea maxLength={500} rows={3} placeholder="Your review" value={form.comment} onChange={(e) => setForm({ ...form, comment: e.target.value })} className="mt-3 w-full rounded-lg border border-input bg-secondary px-4 py-3 outline-none focus:border-primary" />
        <button className="btn-primary mt-4 rounded-full px-6 py-3 font-semibold">Submit Review</button>
        {msg && <p className="mt-3 text-sm text-muted-foreground">{msg}</p>}
      </form>
    </div>
  );
}
