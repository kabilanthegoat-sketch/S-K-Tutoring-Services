import { useState } from "react";
import { z } from "zod";
import { Check } from "lucide-react";
import { subjects, tutors } from "@/lib/site-data";
import { saveEnquiry } from "@/lib/inquiries";

const schema = z.object({
  parent_name: z.string().trim().min(1, "Please enter your name").max(100),
  contact_number: z.string().trim().regex(/^[+\d\s()-]{6,20}$/, "Enter a valid contact number"),
  child_grade: z.string().min(1, "Choose a grade"),
  subject: z.string().min(1, "Choose a subject"),
  preferred_tutor: z.string().max(50),
});
type Data = z.infer<typeof schema>;
const steps = ["Parent", "Learner", "Tutor"];
const field = "w-full rounded-lg border border-input bg-secondary px-4 py-3 outline-none focus:border-primary";

export function InquiryForm() {
  const [step, setStep] = useState(0);
  const [d, setD] = useState<Data>({ parent_name: "", contact_number: "", child_grade: "", subject: "", preferred_tutor: "No preference" });
  const [err, setErr] = useState("");
  const [done, setDone] = useState(false);
  const [busy, setBusy] = useState(false);
  const set = (k: keyof Data, v: string) => setD({ ...d, [k]: v });

  const check = (keys: (keyof Data)[]) => {
    const r = schema.pick(Object.fromEntries(keys.map((k) => [k, true])) as never).safeParse(d);
    if (!r.success) { setErr(r.error.issues[0]?.message ?? "Please check your details"); return false; }
    setErr(""); return true;
  };
  const next = () => {
    if (step === 0 && !check(["parent_name", "contact_number"])) return;
    if (step === 1 && !check(["child_grade", "subject"])) return;
    setStep(step + 1);
  };
  const submit = async () => {
    const r = schema.safeParse(d);
    if (!r.success) return setErr(r.error.issues[0]?.message ?? "Please check your details");
    setBusy(true);
    try {
      const result = await saveEnquiry({ data: r.data });
      if (!result.ok) {
        setErr("Something went wrong. Please try again or WhatsApp us.");
        return;
      }
      setErr("");
      setDone(true);
    } catch {
      setErr("Something went wrong. Please try again or WhatsApp us.");
    } finally {
      setBusy(false);
    }
  };

  if (done) return (
    <div className="glass glow-ring rounded-2xl p-8 text-center">
      <div className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-primary text-primary-foreground"><Check /></div>
      <h3 className="mt-4 text-2xl font-bold">Enquiry received!</h3>
      <p className="mt-2 text-muted-foreground">We'll contact you shortly on {d.contact_number}.</p>
    </div>
  );

  return (
    <div className="glass glow-ring rounded-2xl p-6 sm:p-8">
      <div className="mb-6 flex gap-2">
        {steps.map((s, i) => (
          <div key={s} className="flex-1">
            <div className={`h-1.5 rounded-full ${i <= step ? "bg-primary" : "bg-secondary"}`} />
            <p className={`mt-2 text-xs ${i <= step ? "text-foreground" : "text-muted-foreground"}`}>{i + 1}. {s}</p>
          </div>
        ))}
      </div>
      {step === 0 && (
        <div className="space-y-3">
          <input className={field} placeholder="Parent name" maxLength={100} value={d.parent_name} onChange={(e) => set("parent_name", e.target.value)} />
          <input className={field} placeholder="Contact number" type="tel" maxLength={20} value={d.contact_number} onChange={(e) => set("contact_number", e.target.value)} />
        </div>
      )}
      {step === 1 && (
        <div className="space-y-3">
          <select className={field} value={d.child_grade} onChange={(e) => set("child_grade", e.target.value)}>
            <option value="">Child's grade</option>
            {[4, 5, 6, 7, 8, 9].map((g) => <option key={g}>Grade {g}</option>)}
          </select>
          <select className={field} value={d.subject} onChange={(e) => set("subject", e.target.value)}>
            <option value="">Subject needed</option>
            {subjects.map((s) => <option key={s.key}>{s.title}</option>)}
          </select>
        </div>
      )}
      {step === 2 && (
        <div className="grid grid-cols-2 gap-2">
          {["No preference", ...tutors.map((t) => t.name)].map((n) => (
            <button key={n} type="button" onClick={() => set("preferred_tutor", n)}
              className={`rounded-lg border px-3 py-3 text-sm transition ${d.preferred_tutor === n ? "border-primary bg-accent" : "border-input bg-secondary"}`}>{n}</button>
          ))}
        </div>
      )}
      {err && <p className="mt-3 text-sm text-destructive">{err}</p>}
      <div className="mt-6 flex justify-between gap-3">
        <button disabled={step === 0} onClick={() => setStep(step - 1)} className="btn-ghost rounded-full px-5 py-3 text-sm disabled:opacity-30">Back</button>
        {step < 2
          ? <button onClick={next} className="btn-primary rounded-full px-6 py-3 text-sm font-semibold">Next</button>
          : <button disabled={busy} onClick={submit} className="btn-primary rounded-full px-6 py-3 text-sm font-semibold">{busy ? "Sending…" : "Send Enquiry"}</button>}
      </div>
    </div>
  );
}
