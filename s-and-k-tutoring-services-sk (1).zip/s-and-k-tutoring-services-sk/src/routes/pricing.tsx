import { createFileRoute } from "@tanstack/react-router";
import { Check } from "lucide-react";
import { Calculator } from "@/components/site/Interactive";
import { InquiryForm } from "@/components/site/InquiryForm";

export const Route = createFileRoute("/pricing")({
  head: () => ({
    meta: [
      { title: "Pricing & Enquiries — S&K Tutoring" },
      { name: "description", content: "One flat rate: R60 per hour across all subjects. Send an enquiry in under a minute." },
      { property: "og:title", content: "Pricing & Enquiries — S&K Tutoring" },
      { property: "og:description", content: "R60 per hour, all subjects, Grades 4–9." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Pricing,
});

function Pricing() {
  return (
    <section className="mx-auto max-w-6xl px-5 py-20">
      <div className="text-center">
        <p className="text-sm font-semibold uppercase tracking-widest text-glow">Flexible Tutoring Rates</p>
        <h1 className="mt-4 font-display text-7xl font-extrabold sm:text-9xl"><span className="text-chrome">R60</span></h1>
        <p className="mt-2 text-2xl text-muted-foreground">per hour · across all subjects</p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          {["1-on-1 Dedicated Tutor", "Curriculum Aligned (CAPS)", "Exam & Test Revision", "Pay only for lessons attended"].map((p) => (
            <span key={p} className="glass flex items-center gap-2 rounded-full px-4 py-2 text-sm"><Check className="h-4 w-4 text-glow" />{p}</span>
          ))}
        </div>
      </div>
      <div id="enquire" className="mt-20 grid scroll-mt-24 gap-8 md:grid-cols-2">
        <div>
          <h2 className="text-chrome mb-6 text-3xl font-bold">Smart Enquiry Form</h2>
          <InquiryForm />
        </div>
        <div>
          <h2 className="text-chrome mb-6 text-3xl font-bold">Estimate Your Cost</h2>
          <Calculator />
        </div>
      </div>
    </section>
  );
}
