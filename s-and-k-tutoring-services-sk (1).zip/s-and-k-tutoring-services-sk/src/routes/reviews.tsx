import { createFileRoute } from "@tanstack/react-router";
import { Reviews } from "@/components/site/Interactive";

export const Route = createFileRoute("/reviews")({
  head: () => ({
    meta: [
      { title: "Reviews — S&K Tutoring" },
      {
        name: "description",
        content: "Read feedback from S&K Tutoring families and share your own review.",
      },
      { property: "og:title", content: "Reviews — S&K Tutoring" },
      {
        property: "og:description",
        content: "Read feedback from S&K Tutoring families and share your own review.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ReviewsPage,
});

function ReviewsPage() {
  return (
    <section className="mx-auto max-w-6xl px-5 py-20">
      <header className="mx-auto max-w-2xl text-center">
        <p className="text-sm font-semibold uppercase tracking-widest text-glow">Family feedback</p>
        <h1 className="text-chrome mt-3 text-5xl font-extrabold">Reviews</h1>
        <p className="mt-4 text-muted-foreground">
          Read what parents and students say, or share your experience with S&amp;K Tutoring.
        </p>
      </header>
      <div className="mt-12">
        <Reviews />
      </div>
    </section>
  );
}
