import { createFileRoute, Link } from "@tanstack/react-router";
import { Gift, Check } from "lucide-react";
import { Scene3D, SubjectGrid, Calculator, Reviews, Tilt } from "@/components/site/Interactive";
import { WHATSAPP_2 } from "@/lib/site-data";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "S&K Tutoring Services — Empowering Learners to Succeed" },
      { name: "description", content: "Personalised 1-on-1 tutoring for Grades 4–9. Flat rate of R60 per hour, online and in-person." },
      { property: "og:title", content: "S&K Tutoring Services — Empowering Learners to Succeed" },
      { property: "og:description", content: "Personalised 1-on-1 tutoring for Grades 4–9 at R60 per hour." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Home,
});

const perks = ["Online & In-Person Lessons", "Personalised Support for Every Student", "Practice Activities Included", "Focus on Weak Areas", "Friendly, Patient & Results-Driven"];

function Home() {
  return (
    <>
      <section className="grid-bg relative overflow-hidden">
        <Scene3D />
        <div className="relative mx-auto max-w-4xl px-5 py-24 text-center sm:py-36">
          <span className="inline-block rounded-full border border-primary bg-accent px-4 py-1 text-xs font-semibold uppercase tracking-widest">Grades 4–9</span>
          <h1 className="text-chrome mt-6 text-5xl font-extrabold leading-[1.05] sm:text-7xl">Empowering Learners to <span className="text-blue-glow">Succeed</span></h1>
          <p className="mx-auto mt-6 max-w-xl text-lg text-muted-foreground">Personalized 1-on-1 tutoring tailored to unlock every student's full potential.</p>
          <div className="mt-9 flex flex-wrap justify-center gap-3">
            <Link to="/pricing" hash="enquire" className="btn-primary rounded-full px-8 py-4 font-semibold">Enquire Now</Link>
            <Link to="/tutors" className="btn-ghost rounded-full px-8 py-4 font-semibold">Meet Our Tutors</Link>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5">
        <div className="-mt-8 flex flex-wrap justify-center gap-2">
          {perks.map((p) => <span key={p} className="glass flex items-center gap-2 rounded-full px-4 py-2 text-sm"><Check className="h-4 w-4 text-glow" />{p}</span>)}
        </div>
      </section>

      <section className="mx-auto mt-20 max-w-6xl px-5">
        <Tilt>
          <div className="glass glow-ring relative overflow-hidden rounded-2xl p-8 sm:p-10">
            <div className="flex flex-col items-start gap-6 md:flex-row md:items-center md:justify-between">
              <div>
                <p className="flex items-center gap-2 text-sm font-semibold uppercase tracking-widest text-glow"><Gift className="h-4 w-4" />Refer A Student Program</p>
                <h2 className="mt-2 text-3xl font-bold sm:text-4xl">Together We Grow. Together We Succeed.</h2>
                <p className="mt-3 text-muted-foreground">Refer a friend and <b className="text-foreground">you get 20% OFF</b> next month's tutoring.</p>
              </div>
              <a href={`https://wa.me/${WHATSAPP_2}?text=${encodeURIComponent("Hi! I'd like to refer a friend to S&K Tutoring.")}`} target="_blank" rel="noreferrer" className="btn-primary shrink-0 rounded-full px-7 py-4 font-semibold">Refer a Friend Now</a>
            </div>
          </div>
        </Tilt>
      </section>

      <section className="mx-auto mt-24 max-w-6xl px-5">
        <h2 className="text-chrome text-center text-4xl font-bold">Subjects &amp; Services Offered</h2>
        <p className="mt-3 text-center text-muted-foreground">Click on any subject card below to view detailed lesson summaries!</p>
        <div className="mt-5 text-center">
          <Link to="/subjects" className="btn-ghost inline-flex rounded-full px-5 py-2 text-sm font-semibold">Explore Subjects &amp; Services</Link>
        </div>
        <div className="mt-10"><SubjectGrid /></div>
      </section>

      <section className="mx-auto mt-24 grid max-w-6xl gap-10 px-5 md:grid-cols-2">
        <div>
          <h2 className="text-chrome text-4xl font-bold">Who We Are</h2>
          <p className="mt-5 text-muted-foreground">S&amp;K Tutoring is an energetic, results-driven educational service run by a team of academically strong students who are truly passionate about helping others succeed. We specialize in personalized academic support designed for learners in <b className="text-foreground">Grades 4 through 9</b>.</p>
          <p className="mt-4 text-muted-foreground">By breaking down the curriculum into manageable, easily digestible concepts, our tutors create a friendly, patient, and motivating environment where students don't just memorize information—they master it.</p>
          <div className="mt-6 rounded-xl border-l-4 border-primary bg-accent p-5">
            <p className="font-display font-semibold">Our Mission</p>
            <p className="mt-2 text-sm text-muted-foreground">To identify individual weak areas, transform them into strengths, and provide every child with the tools, practice activities, and confidence they need to excel in school.</p>
          </div>
        </div>
        <Calculator />
      </section>

      <section className="mt-24">
        <h2 className="text-chrome text-center text-4xl font-bold">What Parents &amp; Students Say</h2>
        <p className="mt-3 text-center text-muted-foreground">Read real feedback or leave your own review below!</p>
        <div className="mt-5 text-center">
          <Link to="/reviews" className="btn-ghost inline-flex rounded-full px-5 py-2 text-sm font-semibold">Open Reviews Page</Link>
        </div>
        <div className="mx-auto mt-10 max-w-6xl px-5"><Reviews /></div>
      </section>
    </>
  );
}
