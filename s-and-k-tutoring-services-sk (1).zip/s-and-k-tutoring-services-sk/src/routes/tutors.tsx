import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Tilt } from "@/components/site/Interactive";
import { tutors } from "@/lib/site-data";

export const Route = createFileRoute("/tutors")({
  head: () => ({
    meta: [
      { title: "Meet Our Expert Tutors — S&K Tutoring" },
      { name: "description", content: "Meet Kabilan, Shriyans, Achuma and Luke — S&K Tutoring's passionate Grades 4–9 tutors." },
      { property: "og:title", content: "Meet Our Expert Tutors — S&K Tutoring" },
      { property: "og:description", content: "Academically strong, passionate tutors for Grades 4–9." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Tutors,
});

const filters = ["All", "Mathematics", "Physics", "English", "Afrikaans", "EMS", "Biology"];

function Tutors() {
  const [f, setF] = useState("All");
  const shown = tutors.filter((t) => f === "All" || t.subjects.includes(f));
  return (
    <section className="mx-auto max-w-6xl px-5 py-20">
      <h1 className="text-chrome text-center text-5xl font-extrabold">Meet Our Expert Tutors</h1>
      <p className="mx-auto mt-4 max-w-xl text-center text-muted-foreground">Academically strong, passionate, and dedicated to transforming your child's results.</p>
      <div className="mt-8 flex flex-wrap justify-center gap-2">
        {filters.map((x) => (
          <button key={x} onClick={() => setF(x)} className={`rounded-full px-4 py-2 text-sm transition ${f === x ? "btn-primary" : "btn-ghost"}`}>{x === "All" ? "Show All Specialties" : x}</button>
        ))}
      </div>
      <div className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {shown.map((t) => (
          <Tilt key={t.name}>
            <article className="glass h-full rounded-2xl p-6 text-center transition hover:glow-ring">
              {t.photo
                ? <img src={t.photo} alt={t.name} className="mx-auto h-28 w-28 rounded-full object-cover ring-2 ring-primary" />
                : <div className="mx-auto grid h-28 w-28 place-items-center rounded-full bg-accent font-display text-4xl font-bold ring-2 ring-primary">{t.name[0]}</div>}
              <h2 className="mt-5 text-xl font-bold">{t.name}</h2>
              <p className="mt-1 text-sm text-glow">{t.role}</p>
              <div className="mt-4 flex flex-wrap justify-center gap-1.5">
                {t.subjects.map((s) => <span key={s} className="rounded-full border border-border bg-secondary px-2.5 py-1 text-xs">{s}</span>)}
              </div>
            </article>
          </Tilt>
        ))}
      </div>
    </section>
  );
}
