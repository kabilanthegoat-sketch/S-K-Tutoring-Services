import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { ChevronDown, Receipt } from "lucide-react";
import { faqs } from "@/lib/site-data";

export const Route = createFileRoute("/faq")({
  head: () => ({
    meta: [
      { title: "FAQ & Payments — S&K Tutoring" },
      { name: "description", content: "How lessons, invoices and monthly payments work at S&K Tutoring." },
      { property: "og:title", content: "FAQ & Payments — S&K Tutoring" },
      { property: "og:description", content: "Answers about lessons, invoices and payments." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Faq,
});

function Faq() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <section className="mx-auto max-w-3xl px-5 py-20">
      <h1 className="text-chrome text-center text-5xl font-extrabold">Frequently Asked Questions</h1>
      <div className="glass glow-ring mt-10 flex gap-4 rounded-2xl p-6">
        <Receipt className="h-6 w-6 shrink-0 text-glow" />
        <p>Invoices are sent at the end of every month. Your monthly total is calculated dynamically based strictly on the number of lessons your child attended.</p>
      </div>
      <div className="mt-8 space-y-3">
        {faqs.map((f, i) => (
          <div key={f.q} className={`glass rounded-xl transition ${open === i ? "border-primary" : ""}`}>
            <button onClick={() => setOpen(open === i ? null : i)} className="flex w-full items-center justify-between gap-4 p-5 text-left font-semibold">
              {f.q}<ChevronDown className={`h-5 w-5 shrink-0 transition ${open === i ? "rotate-180 text-glow" : ""}`} />
            </button>
            {open === i && <p className="px-5 pb-5 text-muted-foreground animate-in fade-in">{f.a}</p>}
          </div>
        ))}
      </div>
    </section>
  );
}
