import { createFileRoute } from "@tanstack/react-router";
import { SubjectGrid } from "@/components/site/Interactive";

export const Route = createFileRoute("/subjects")({
  head: () => ({
    meta: [
      { title: "Subjects & Services — S&K Tutoring" },
      {
        name: "description",
        content: "Explore S&K Tutoring subjects and learning support for Grades 4–9.",
      },
      { property: "og:title", content: "Subjects & Services — S&K Tutoring" },
      {
        property: "og:description",
        content: "Explore subjects and personalised learning support for Grades 4–9.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SubjectsPage,
});

function SubjectsPage() {
  return (
    <section className="mx-auto max-w-6xl px-5 py-20">
      <header className="mx-auto max-w-2xl text-center">
        <p className="text-sm font-semibold uppercase tracking-widest text-glow">Grades 4–9</p>
        <h1 className="text-chrome mt-3 text-5xl font-extrabold">Subjects &amp; Services</h1>
        <p className="mt-4 text-muted-foreground">
          Choose a subject or service to see the skills and topics our tutors can help your learner
          build.
        </p>
      </header>
      <div className="mt-12">
        <SubjectGrid />
      </div>
    </section>
  );
}
