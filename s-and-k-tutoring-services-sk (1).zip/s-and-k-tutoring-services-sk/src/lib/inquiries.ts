import { createServerFn } from "@tanstack/react-start";

const spreadsheetId = "1EFpNZtnid5Al5dKLkZNALOdni2tKGMLFKn6p7OeIIKI";

type EnquiryData = {
  parent_name: string;
  contact_number: string;
  child_grade: string;
  subject: string;
  preferred_tutor: string;
};

function validateEnquiry(input: unknown): EnquiryData {
  if (input == null || typeof input !== "object" || Array.isArray(input)) {
    throw new TypeError("Invalid enquiry data.");
  }

  const record = input as Record<string, unknown>;
  const expectedFields = [
    "parent_name",
    "contact_number",
    "child_grade",
    "subject",
    "preferred_tutor",
  ];
  if (
    Object.keys(record).length !== expectedFields.length ||
    expectedFields.some((field) => !(field in record))
  ) {
    throw new TypeError("Invalid enquiry data.");
  }

  const { parent_name, contact_number, child_grade, subject, preferred_tutor } = record;
  if (
    typeof parent_name !== "string" ||
    parent_name.trim().length < 1 ||
    parent_name.trim().length > 100 ||
    typeof contact_number !== "string" ||
    !/^[+\d\s()-]{6,20}$/.test(contact_number.trim()) ||
    typeof child_grade !== "string" ||
    child_grade.length < 1 ||
    child_grade.length > 20 ||
    typeof subject !== "string" ||
    subject.length < 1 ||
    subject.length > 50 ||
    typeof preferred_tutor !== "string" ||
    preferred_tutor.length > 50
  ) {
    throw new TypeError("Invalid enquiry data.");
  }

  return {
    parent_name: parent_name.trim(),
    contact_number: contact_number.trim(),
    child_grade,
    subject,
    preferred_tutor,
  };
}

export const saveEnquiry = createServerFn({ method: "POST" })
  .validator(validateEnquiry)
  .handler(async ({ data }) => {
    try {
      const { ReplitConnectors } = await import("@replit/connectors-sdk");
      const connectors = new ReplitConnectors();
      const range = encodeURIComponent("Enquiries!A:F");
      const response = await connectors.proxy(
        "google-sheet",
        `/v4/spreadsheets/${spreadsheetId}/values/${range}:append?valueInputOption=RAW&insertDataOption=INSERT_ROWS`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            majorDimension: "ROWS",
            values: [
              [
                new Date().toISOString(),
                data.parent_name,
                data.contact_number,
                data.child_grade,
                data.subject,
                data.preferred_tutor,
              ],
            ],
          }),
        },
      );

      if (!response.ok) {
        console.error(`[enquiries] Google Sheets append failed (${response.status}).`);
        return { ok: false };
      }

      return { ok: true };
    } catch (error) {
      console.error(
        "[enquiries] Google Sheets request failed.",
        error instanceof Error ? error.message : "Unknown error",
      );
      return { ok: false };
    }
  });
